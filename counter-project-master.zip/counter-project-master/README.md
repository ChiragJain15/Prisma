# CountDown Timer Launch Soon Landing Page

Launch soon timer page ui inspired from front end mentor challange site.
click on this link to check this project out -> https://chiragjain15.github.io/counter-project

![screenshot of the landing page](/images/timer.png)
